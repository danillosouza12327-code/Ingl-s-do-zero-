# Inglês do Zero
Requer Node 22.13+. Rodar: `ADMIN_EMAIL=voce@email.com ADMIN_PASSWORD=SuaSenha npm start` (abre em http://localhost:3000).
Variáveis: PORT, DATA_DIR (pasta do banco — use disco persistente), SECRET, ANTHROPIC_API_KEY (Professor Alex).
Faça backup da pasta data/ (app.db). Use HTTPS na hospedagem.
